# SharpHound Debug Builds
To use this build, place the exe and the .pdb file in the same folder and then run the command that led to an exception/error

## Useful Flags
* Set threads to 1 (-t 1)
* Set verbosity to most verbose (-v 0)